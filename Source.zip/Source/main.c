#include "MDR32Fx.h"
#include "arm_math.h"
#include "MDR32F9Qx_usb_handlers.h"

#include "timer_control.h"
#include "can.h"
#include "usb.h"

uint8_t Buffer[BUFFER_LENGTH];

int main (void) {	
	
	VCOM_Configuration();
	USB_CDC_Init(Buffer, 8, SET);
	
	CLK_init();  
	USB_init();
   
  timer_control_init(); 
  CAN_init(); 

	while (1) {   
	}	
}


