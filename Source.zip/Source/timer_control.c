/* MODULE TIMER. */

#include "MDR32Fx.h"
#include "MDR32F9Qx_port.h"
#include "MDR32F9Qx_timer.h"
#include "MDR32F9Qx_rst_clk.h"
#include "timer_control.h"
#include "can.h"


const TIMER_CntInitTypeDef timer_control_structure = { 
	0, 																	// CNT
	0,                                  // Prescaler = 1
	40000,                         			// Period
	TIMER_CntMode_ClkChangeDir,         // CenterAlignCounterMode
	TIMER_CntDir_Up,                    // direction - doesn't work
	TIMER_EvSrc_None,                   // TIM_CLK - TIMER Event Source   
	TIMER_FDTS_TIMER_CLK_div_1,         // each TIMER_CLK clock 
	TIMER_ARR_Update_On_CNT_Overflow,   // update on overflow
	TIMER_Filter_8FF_at_TIMER_CLK,      // ETR filter
	TIMER_ETR_Prescaler_div_2,          // ETR Prescaler
	TIMER_ETRPolarity_NonInverted,      // ETR Polarity
	TIMER_BRKPolarity_Inverted,       	// BRK Polarity
};

void timer_control_init(void) {  
	/* Enable Timer  clock */  
	RST_CLK_PCLKcmd(RST_CLK_PCLK_TIMER1, ENABLE);
  MDR_RST_CLK->TIM_CLOCK |= 1<<24;	

  // Reset timer
  TIMER_DeInit(MDR_TIMER1);              
  
  // Timer init
  TIMER_CntInit(MDR_TIMER1, &timer_control_structure); 
  
  // Run timer
  TIMER_Cmd(MDR_TIMER1, ENABLE);        
    	
  // Clears the TIMER's pending flags.
  TIMER_ClearFlag(MDR_TIMER1, TIMER_STATUS_Msk);

  // Enables the specified TIMER interrupts.
  TIMER_ITConfig(MDR_TIMER1, TIMER_STATUS_CNT_ARR, ENABLE);

  // Enable and set priority interrupts.
  NVIC_SetPriority (Timer1_IRQn, 7);  // 0 - max prioritet
  NVIC_EnableIRQ(Timer1_IRQn);  
}

void Timer1_IRQHandler() {

  if (TIMER_GetFlagStatus(MDR_TIMER1, TIMER_STATUS_CNT_ARR_EVENT)) {   	
    CAN_Handler();
  }   
  
  // Crear interrupt's flags 
  TIMER_ClearFlag(MDR_TIMER1,TIMER_STATUS_CNT_ARR_EVENT);     
}

void CLK_init(void) {
  
	MDR_RST_CLK->HS_CONTROL = 0x01; /* resonator HSE on */
  while ((MDR_RST_CLK->CLOCK_STATUS&0x04) == 0x00); /* wait while HSE not ready */
 
  MDR_RST_CLK->CPU_CLOCK = (2 | (0 << 2) | (0 << 4) | (1 << 8));/* CPU_C1=HSE, CPU_C2=CPU_C1, CPU_C3=CPU_C2, HCLK=CPU_C3*/
   
  MDR_RST_CLK->PLL_CONTROL=(1<<3);			              // restart PLL  
  MDR_RST_CLK->PLL_CONTROL = ((1 << 2) | (4 << 8));   //on PLL | PLL_MUL = 5
  
	while ((MDR_RST_CLK->CLOCK_STATUS & 0x02) == 0x00); //wait while PLL not ready
  
	RST_CLK_PCLKcmd(RST_CLK_PCLK_EEPROM, ENABLE);	    // EEPROM_CTRL Clock enable				
	MDR_EEPROM->CMD = 3<<3;								              // Delay = 3 ( 80MHz/(3+1) = 20 MHz<25MHz)
	RST_CLK_PCLKcmd(RST_CLK_PCLK_EEPROM, DISABLE);	  // EEPROM_CTRL Clock disable		  
  
  MDR_RST_CLK->CPU_CLOCK = (2 | (1 << 2) | (0 << 4) | (1 << 8));/* CPU_C1=HSE, CPU_C2=PLLCPU, CPU_C3=CPU_C2, HCLK=CPU_C3*/
	// => Summary HCLK = 80MHz from HSE resonator
}
