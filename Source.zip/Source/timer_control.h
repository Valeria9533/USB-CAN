/* MODULE TIMER. */

void timer_control_init(void);
void CLK_init (void);
void Timer1_IRQHandler(void);

/* END TIMER */