/* MODULE USB. */

#include "MDR32Fx.h"
#include "MDR32F9Qx_port.h"
#include "MDR32F9Qx_rst_clk.h"
#include "MDR32F9Qx_usb.h"
#include "MDR32F9Qx_can.h"
#include "MDR32F9Qx_usb_handlers.h"

#include "usb.h"

#ifdef USB_CDC_LINE_CODING_SUPPORTED
static USB_CDC_LineCoding_TypeDef LineCoding;
#endif

#ifdef USB_CDC_LINE_CODING_SUPPORTED
static USB_CDC_LineCoding_TypeDef LineCoding;
#endif /* USB_CDC_LINE_CODING_SUPPORTED */

#ifdef USB_VCOM_SYNC
volatile uint32_t PendingDataLength = 0;
#endif /* USB_VCOM_SYNC */

/* USB protocol debugging */
#ifdef USB_DEBUG_PROTO

#define USB_DEBUG_NUM_PACKETS   100

typedef struct {
  USB_SetupPacket_TypeDef packet;
  uint32_t address;
} TDebugInfo;

static TDebugInfo SetupPackets[USB_DEBUG_NUM_PACKETS];
static uint32_t SPIndex;
static uint32_t ReceivedByteCount, SentByteCount, SkippedByteCount;

#endif /* USB_DEBUG_PROTO */

USB_DeviceBUSParam_TypeDef USB_DeviceBUSParam;
USB_Clock_TypeDef USB_Clock_InitStruct;

extern CAN_TxMsgTypeDef TxMsg;  
extern CAN_RxMsgTypeDef RxMsg;
extern uint8_t Buffer[BUFFER_LENGTH];

/* Задание конфигурации последовательной линии связи которую может прочитать хост */
void VCOM_Configuration(void)
{
	#ifdef USB_CDC_LINE_CODING_SUPPORTED
  LineCoding.dwDTERate = 115200;
  LineCoding.bCharFormat = 0;
  LineCoding.bParityType = 0;
  LineCoding.bDataBits = 8;
	#endif /* USB_CDC_LINE_CODING_SUPPORTED */
}

/* USB Device layer setup and powering on */
void USB_init(void)
{
  /* Enables the CPU_CLK clock on USB */
  RST_CLK_PCLKcmd(RST_CLK_PCLK_USB, ENABLE);

  /* Device layer initialization */
	MDR_RST_CLK->PLL_CONTROL |= (1<<0)|(2<<4); // PLL USB on, PLL_MULL = (2+1) = 3; 16 * 3 = 48MHz
	while (!(MDR_RST_CLK->CLOCK_STATUS & (1<<2))); // Р–РґРµРј, РїРѕРєР° PLL USB СЃС‚Р°Р±РёР»РёР·РёСЂСѓРµС‚СЃСЏ
	
	MDR_RST_CLK->PER_CLOCK |= (1<<3);     // Enable USB block clocking
	MDR_RST_CLK->USB_CLOCK = 0x00000006;  // USB_C2 Clock = PLL

  USB_DeviceBUSParam.MODE  = USB_SC_SCFSP_Full;
  USB_DeviceBUSParam.SPEED = USB_SC_SCFSR_12Mb;
  USB_DeviceBUSParam.PULL  = USB_HSCR_DP_PULLUP_Set;

  USB_DeviceInit(&USB_Clock_InitStruct, &USB_DeviceBUSParam);

  /* Enable all USB interrupts */
  USB_SetSIM(USB_SIS_Msk);

  USB_DevicePowerOn();

  /* Enable interrupt on USB */
	#ifdef USB_INT_HANDLE_REQUIRED
		NVIC_EnableIRQ(USB_IRQn);
	#endif /* USB_INT_HANDLE_REQUIRED */

  USB_DEVICE_HANDLE_RESET;
}

/* USB_CDC_HANDLE_DATA_RECEIVE implementation - data echoing */
USB_Result USB_CDC_RecieveData(uint8_t* Buffer, uint32_t Length)
{
  USB_Result result;

#ifdef USB_DEBUG_PROTO
  ReceivedByteCount += Length;
#endif /* USB_DEBUG_PROTO */

  /* Send back received data portion */
  result = USB_CDC_SendData(Buffer, Length); 
	
	/* Put data to CAN buffer */
	TxMsg.Data[0] = 0;
	TxMsg.Data[1] = 0;
	
	for(uint8_t i=0; i<4; i++) {
		TxMsg.Data[0] += Buffer[i+4]<<(24-8*i);
		TxMsg.Data[1] += Buffer[i]<<(24-8*i);
	}
	
	TxMsg.IDE     = CAN_ID_STD;
	TxMsg.DLC     = 0x08;
	TxMsg.PRIOR_0 = DISABLE;
	TxMsg.ID      = CAN_STDID_TO_EXTID(0x201);
	
	CAN_Transmit(MDR_CAN1, 0, &TxMsg); 

#ifdef USB_DEBUG_PROTO
  if (result == USB_SUCCESS)
  {
    SentByteCount += Length;
  }
#ifndef USB_VCOM_SYNC
  else
  {
    SkippedByteCount += Length;
  }
#endif /* !USB_VCOM_SYNC */
#endif /* USB_DEBUG_PROTO */

#ifdef USB_VCOM_SYNC
  if (result != USB_SUCCESS)
  {
    /* If data cannot be sent now, it will await nearest possibility
     * (see USB_CDC_DataSent) */
    PendingDataLength = Length;
  }
  return result;
	#else
		return USB_SUCCESS;
	#endif /* USB_VCOM_SYNC */ 
}


#ifdef USB_VCOM_SYNC

/* USB_CDC_HANDLE_DATA_SENT implementation - sending of pending data */
USB_Result USB_CDC_DataSent(void)
{
  USB_Result result = USB_SUCCESS;

  if (PendingDataLength)
  {
    result = USB_CDC_SendData(Buffer, PendingDataLength);
		#ifdef USB_DEBUG_PROTO
    if (result == USB_SUCCESS)
    {
      SentByteCount += PendingDataLength;
    }
    else
    {
      SkippedByteCount += PendingDataLength;
    }
		#endif /* USB_DEBUG_PROTO */
    PendingDataLength = 0;
    USB_CDC_ReceiveStart();
  }
  return USB_SUCCESS;
}

#endif /* USB_VCOM_SYNC */


#ifdef USB_CDC_LINE_CODING_SUPPORTED

/* USB_CDC_HANDLE_GET_LINE_CODING implementation example */
USB_Result USB_CDC_GetLineCoding(uint16_t wINDEX, USB_CDC_LineCoding_TypeDef* DATA)
{
  assert_param(DATA);
  if (wINDEX != 0)
  {
    /* Invalid interface */
    return USB_ERR_INV_REQ;
  }

  /* Just store received settings */
  *DATA = LineCoding;
  return USB_SUCCESS;
}

/* USB_CDC_HANDLE_SET_LINE_CODING implementation example */
USB_Result USB_CDC_SetLineCoding(uint16_t wINDEX, const USB_CDC_LineCoding_TypeDef* DATA)
{
  assert_param(DATA);
  if (wINDEX != 0)
  {
    /* Invalid interface */
    return USB_ERR_INV_REQ;
  }

  /* Just send back settings stored earlier */
  LineCoding = *DATA;
  return USB_SUCCESS;
}

#endif /* USB_CDC_LINE_CODING_SUPPORTED */

#ifdef USB_DEBUG_PROTO

/* Overwritten USB_DEVICE_HANDLE_SETUP default handler - to dump received setup packets */
USB_Result USB_DeviceSetupPacket_Debug(USB_EP_TypeDef EPx, const USB_SetupPacket_TypeDef* USB_SetupPacket)
{

#ifdef USB_DEBUG_PROTO
  SetupPackets[SPIndex].packet = *USB_SetupPacket;
  SetupPackets[SPIndex].address = USB_GetSA();
  SPIndex = (SPIndex < USB_DEBUG_NUM_PACKETS ? SPIndex + 1 : 0);
#endif /* USB_DEBUG_PROTO */

  return USB_DeviceSetupPacket(EPx, USB_SetupPacket);
}

#endif /* USB_DEBUG_PROTO */



/**
  * @brief  Reports the source file ID, the source line number
  *         and expression text (if USE_ASSERT_INFO == 2) where
  *         the assert_param error has occurred.
  * @param  file_id: pointer to the source file name
  * @param  line: assert_param error line source number
  * @param  expr:
  * @retval None
  */
#if (USE_ASSERT_INFO == 1)
void assert_failed(uint32_t file_id, uint32_t line)
{
  /* User can add his own implementation to report the source file ID and line number.
     Ex: printf("Wrong parameters value: file Id %d on line %d\r\n", file_id, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#elif (USE_ASSERT_INFO == 2)
void assert_failed(uint32_t file_id, uint32_t line, const uint8_t* expr);
{
  /* User can add his own implementation to report the source file ID, line number and
     expression text.
     Ex: printf("Wrong parameters value (%s): file Id %d on line %d\r\n", expr, file_id, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif /* USE_ASSERT_INFO */