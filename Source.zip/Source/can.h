/* MODULE CAN. */

#define can MDR_CAN1

void CAN_init(void);
void CAN_Handler(void);

/* END CAN */
