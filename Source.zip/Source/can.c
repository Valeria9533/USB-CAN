/* MODULE CAN. */

#include "MDR32Fx.h"
#include "MDR32F9Qx_port.h"
#include "MDR32F9Qx_rst_clk.h"
#include "MDR32F9Qx_can.h"
#include "MDR32F9Qx_usb_handlers.h"

#include "can.h"
#include "usb.h"

#define tx_buf 0
#define rx_buf 1

// CAN
CAN_InitTypeDef  can_structure;
CAN_TxMsgTypeDef TxMsg;  
CAN_RxMsgTypeDef RxMsg;

extern uint8_t Buffer[100];

const PORT_InitTypeDef CAN_TX = {
	PORT_Pin_1,
	PORT_OE_OUT,
	PORT_PULL_UP_OFF,
	PORT_PULL_DOWN_OFF,
	PORT_PD_SHM_ON,
	PORT_PD_DRIVER,
	PORT_GFEN_ON,
	PORT_FUNC_OVERRID,
	PORT_SPEED_MAXFAST,
	PORT_MODE_DIGITAL
};
  
const PORT_InitTypeDef CAN_RX = {
	PORT_Pin_7,
	PORT_OE_IN,
	PORT_PULL_UP_OFF,
	PORT_PULL_DOWN_OFF,
	PORT_PD_SHM_ON,
	PORT_PD_DRIVER,
	PORT_GFEN_ON,
	PORT_FUNC_ALTER,
	PORT_SPEED_MAXFAST,
	PORT_MODE_DIGITAL
};		
  
void CAN_init(void) {		// CANT-PE1, CANR-PA7	
	
	/* Enable GPIO, CAN  clock */
	RST_CLK_PCLKcmd(RST_CLK_PCLK_PORTA | RST_CLK_PCLK_PORTE | RST_CLK_PCLK_CAN1, ENABLE);	

  /* Set the HCLK division factor = 1 for CAN1*/
  CAN_BRGInit(can,CAN_HCLKdiv1);  
  
	// Configure TX
	PORT_Init(MDR_PORTE,&CAN_TX);
  
	// Configure RX
	PORT_Init(MDR_PORTA,&CAN_RX);  
    
  //Reset CAN
  CAN_DeInit(can);  
		
  /* CAN structure init */
  CAN_StructInit (&can_structure);

  can_structure.CAN_ROP  = DISABLE;
  can_structure.CAN_SAP  = ENABLE;  
  can_structure.CAN_STM  = DISABLE;
  can_structure.CAN_ROM  = DISABLE;
  can_structure.CAN_PSEG = CAN_PSEG_Mul_3TQ;
  can_structure.CAN_SEG1 = CAN_SEG1_Mul_8TQ;
  can_structure.CAN_SEG2 = CAN_SEG2_Mul_4TQ;
  can_structure.CAN_SJW  = CAN_SJW_Mul_1TQ;
  can_structure.CAN_SB   = CAN_SB_3_SAMPLE;  
//  can_structure.CAN_BRP  = 39;  // 125kBit
//  can_structure.CAN_BRP  = 19;  // 250kBit
//  can_structure.CAN_BRP  = 9;  // 500kBit
  can_structure.CAN_BRP  = 4;  // 1MBit

  CAN_Init(MDR_CAN1,&can_structure);
  CAN_Cmd(can, ENABLE);
    
  /* receive buffer enable */ 
  CAN_Receive(can, rx_buf, ENABLE);    
  CAN_FilterInitTypeDef Filter_ID = {0,0x1FFFFFFF};
  Filter_ID.Filter_ID=CAN_STDID_TO_EXTID(0x101);  
  CAN_FilterInit(can, rx_buf, &Filter_ID);
}

void CAN_Handler(void) {
  
	if ((CAN_GetRx(MDR_CAN1)&(1<<1))!=0) {   
    
		CAN_GetRawReceivedData(MDR_CAN1, 1, &RxMsg);  
    CAN_ITClearRxTxPendingBit(MDR_CAN1, 1, CAN_STATUS_RX_READY);

    TxMsg.IDE     = CAN_ID_STD;
    TxMsg.DLC     = 0x08;
    TxMsg.PRIOR_0 = DISABLE;
    TxMsg.ID      = CAN_STDID_TO_EXTID(0x201);

		/* Put data to USB buffer */
		for(uint8_t i=0; i<4; i++) {
			Buffer[i] = (RxMsg.Data[1]>>(24-8*i))&0xff;
			Buffer[i+4] = (RxMsg.Data[0]>>(24-8*i))&0xff;
		}

		USB_CDC_SendData(Buffer, BUFFER_LENGTH);
  }
}

/* END CAN. */

