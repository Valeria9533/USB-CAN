/* MODULE USB. */

#define usb MDR_USB
#define BUFFER_LENGTH 8

void USB_init(void);
void USB_Handler(void);
void USB_SendData(void);
void USB_ReceiveData(void);
void VCOM_Configuration(void);

/* END USB */
